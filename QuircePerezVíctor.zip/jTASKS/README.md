jTasks

Introducción

Una empresa nos plantea el desarrollo de una aplicación en Java y para cualquier
plataforma de escritorio (Mac OSX, Linux, Windows, etc.), que permita a los estudiantes
organizar y llevar un registro de las tareas que realizan a lo largo del curso académico.
La aplicación será inicialmente de consola pero la empresa pretende en el futuro añadir
otro tipo de interfaces (como interfaz gráfica o incluso que sea un asistente personal que
permita añadir estas tareas por voz). Por este motivo es importante que en el diseño de
la aplicación se tomen ciertas decisiones para poder crear capas de abstracción en ciertas
partes de la aplicación y que la aplicación tenga una buena arquitectura para poder
hacer cambios y ser probada de forma automática en el futuro.



Requisitos

Los requisitos funcionales de la aplicación se resumen en las siguientes secciones:


● Capacidad de realizar operaciones CRUD de las tareas: las tareas tendrán
cierta información obligatoria que se detalla en el apartado de diseño. La interfaz
gráfica deberá permitir las siguientes operaciones CRUD:

    ○ Dar de alta una tarea a partir de los datos proporcionados por el usuario

    ○ Listados:

        ■ Listado de todas las tareas que están sin completar, ordenadas por
        prioridad (mayor a menor).
        ■ Listado del historial completo de tareas (completadas o no).

    ○ Detalle de la tarea. Solo se mostrará el detalle de la tarea seleccionada de
    uno de los listados anteriores y desde ahí se dará la opción al usuario de:
        ■ Marcar como completada/pendiente (se mostrará una opción
        distinta dependiendo del estado).
        ■ Modificación de toda de la información salvo el código de
        identificación que será único.
        ■ Eliminar la tarea.
● Exportación/Importación como CSV: la aplicación permitirá exportar/importar
en formato CSV las tareas dadas de alta ordenadas por fecha (más recientes
primero). La política de importación será la de no importar aquellas que tengan el
mismo identificador único.

    ● Exportación/Importación como JSON: Similar al anterior pero en formato JSON.
    ● Persistencia: el programa, deberá ser capaz de recuperar el estado de la
    aplicación con las tareas disponibles. Para este fin, como opción por defecto, se
    utilizará el mecanismo de serialización en Java para guardar la información del
    modelo. Se cargará la información en el inicio de la aplicación y se guardará al
    salir de esta. Esta persistencia se abstraerá con una interfaz que permitirá
    cambiar la persistencia de la aplicación en su inicio mediante un parámetro por
    1
    consola. Adicionalmente esta persistencia podrá cambiar realizándose en un
    proveedor externo, en este caso Notion.
    ● Interfaces de usuario: el prototipo deberá contar con una interfaz por consola
    con un menú interactivo pero también estará abierto a extensión ya que en futuro
    se quieren implementar otras interfaces (GUI, voz, etc). Un buen diseño de POO es
    vital en esta parte. Se deberán implementar al menos la primera de las siguientes
    interfaces de usuario:

    ○ Interfaz de consola simple interactiva: Dispondrá de un menú y submenús
        para distintas opciones. Será la opción por defecto de la aplicación.
    ○ CLIView: en el futuro la empresa quiere añadir una opción de usar la
        aplicación solo por parámetros de consola y en un solo uso.
        [Opcional no evaluable]
    ○ VoiceView: en el futuro se desea hacer una vista que narra las opciones del
        menú con un TextToSpeech.
        [Opcional no evaluable]


● Aplicación robusta y resistente a fallos: la funcionalidad del prototipo debe de
haber sido probada manualmente en modo interactivo, revisando toda la
funcionalidad implementada. Si una característica no funciona la empresa no
la valorará. Se deberán manejar excepciones e informar al usuario de posibles
errores debidamente, sin la parada abrupta de la aplicación.


● Arquitectura MVC: un punto clave del desarrollo de la aplicación es que siga las
guías de diseño del estilo arquitectónico Modelo Vista Controlador tratadas a lo
largo del curso en la asignatura. No solo debe funcionar sino que se debe seguir la
arquitectura especificada.


● One More Thing: el CEO de la empresa es un apasionado de la aplicación Notion y
nos exige que sea posible que la persistencia de la aplicación se integre con
Notion. El CEO quiere presentar esta característica como extra en la presentación
del prototipo, solo así considerará que el trabajo es digno de un 10.

● Además, se incluira un PDF explicativo en el que se mostraran las funcionalidades del programa, 
con captura y explicacion.
