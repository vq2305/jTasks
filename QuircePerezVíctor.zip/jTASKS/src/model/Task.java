package model;

import java.util.Date;
import java.util.Locale;



import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;


public class Task implements Serializable{
    private static final long serialVersionUID = 1L;
    private long identifier;
    private String title;
    private Date date;
    private String content;
    private int priority;
    private int estimatedDuration;
    private boolean completed;


    public Task() {
    }
    
    public Task(long identifier, String title, Date date, String content, 
                int priority, int estimatedDuration, boolean completed) {
        this.identifier = identifier;
        this.title = title;
        this.date = date;
        this.content = content;
        this.priority=priority;
        this.estimatedDuration = estimatedDuration;
        this.completed = completed;
    }

    public long getIdentifier() {
        return identifier;
    }

    public void setIdentifier(long identifier) {
        this.identifier = identifier;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        if (priority >= 1 && priority <= 5) {
            this.priority = priority;
        } else {
            throw new IllegalArgumentException("La prioridad debe ser un valor entre 1 y 5.");
        }
    }

    public int getEstimatedDuration() {
        return estimatedDuration;
    }

    public void setEstimatedDuration(int estimatedDuration) {
        this.estimatedDuration = estimatedDuration;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public String toString() {
        return "Task{" +
                "Identificador=" + identifier +
                ", Titulo='" + title + '\'' +
                ", Fecha=" + date +
                ", Contenido='" + content + '\'' +
                ", Prioridad=" + priority +
                ", Duracion Estimada=" + estimatedDuration +
                ", ¿Completada?=" + completed +
                '}';
    }

    public String getInstanceAsDelimitedString(String delimiter) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);

        return String.format(Locale.ENGLISH,
                "%d" + delimiter + "%s" + delimiter + "%s" + delimiter + "%s" +
                        delimiter + "%d" + delimiter + "%d" + delimiter + "%b",
                identifier, 
                title, 
                date != null ? dateFormat.format(date) : "null", 
                content, 
                priority, 
                estimatedDuration, 
                completed);
    }


public static Task getTaskFromDelimitedString(String delimitedString, String delimiter) throws RepositoryException{
    // Dividir la cadena delimitada
    String[] chunks = delimitedString.split(delimiter);

    // Validar que tenga exactamente 7 elementos
    if (chunks.length != 7) {
        return null;
    }

    try {
        // Extraer y convertir los valores de los campos
        long identifier = Long.parseLong(chunks[0]);
        String title = chunks[1];
        
        // Parsear la fecha
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        Date date = chunks[2].equalsIgnoreCase("null") ? null : dateFormat.parse(chunks[2]);
        
        String content = chunks[3];
        int priority = Integer.parseInt(chunks[4]);
        int estimatedDuration = Integer.parseInt(chunks[5]);
        boolean completed = Boolean.parseBoolean(chunks[6]);

        // Crear y devolver la instancia de Task
        return new Task(identifier, title, date, content, priority, estimatedDuration, completed);
    } catch (NumberFormatException |ParseException e) {
            throw new RepositoryException("Error al importar: "+ e);
    }
}


    public static String convertLongToString(long value) {
        return Long.toString(value);
    }
    
}




