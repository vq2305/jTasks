package model;

import java.util.ArrayList;
import java.util.List;
import java.nio.file.Path;


public interface IExporter {
    boolean exportTasks(ArrayList<Task> tasks, Path path) throws RepositoryException;
    List<Task> importTasks(Path path) throws RepositoryException;
}
