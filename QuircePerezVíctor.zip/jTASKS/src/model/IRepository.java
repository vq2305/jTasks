package model;

import java.util.ArrayList;

 public interface IRepository {

    

    ArrayList<Task> getAllTasks() throws RepositoryException;

    boolean addTask(Task task) throws RepositoryException;

    ArrayList<Task> getTasksByPriority() throws RepositoryException;

    Task getTaskById(long taskId) throws RepositoryException;

    boolean deleteTask(long taskId) throws RepositoryException;

    boolean isCompleted(long taskId) throws RepositoryException;

    boolean markTaskAsIncompleted(long taskId) throws RepositoryException;

    boolean markTaskAsCompleted(long taskId) throws RepositoryException;

    boolean updateTask(Task task) throws RepositoryException;

    boolean loadData() throws RepositoryException;

    boolean saveData() throws RepositoryException;
}
