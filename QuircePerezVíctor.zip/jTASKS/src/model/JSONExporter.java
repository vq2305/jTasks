package model;



import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;



public class JSONExporter implements IExporter {
    
    


    
        
    
        
    @Override
    public boolean exportTasks(ArrayList<Task> tasks, Path path) throws RepositoryException {
    
    // Ordenar las tareas por fecha (más recientes primero)
    tasks.sort(Comparator.comparing(Task::getDate).reversed());
   
    File file = path.toFile();
        if (file.exists() && !file.canWrite()) {
            throw new RepositoryException("No se puede escribir en el archivo: " + file.getAbsolutePath());
        }
    
    try {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        
        String json = gson.toJson(tasks);
        Files.write(file.toPath(), json.getBytes(StandardCharsets.UTF_8));
        return true;
    } catch (IOException ex) {
        throw new RepositoryException("Error al exportar tareas al archivo: " + file.getPath(), ex);
    }
}

    
        @Override
        public List<Task> importTasks(Path path) throws RepositoryException {
            
            File f = path.toFile();
            if (f.isFile() && f.exists()) {
            try {
                Gson gson = new Gson();
                String json = new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
                // Obtiene el tipo de la lista
                Type tipoDeLista = new TypeToken<List<Task>>() {}.getType();
                List<Task> tasks = gson.fromJson(json, tipoDeLista);

                // Ordenar las tareas por fecha (más recientes primero)
                tasks.sort(Comparator.comparing(Task::getDate).reversed());
                
                return tasks;
            } catch (IOException ex) {
               
                throw new RepositoryException("Error al importar tareas desde el archivo: " + f.getPath(), ex);
    
            }
            }
    
            else{
            throw new RepositoryException("Error al leer el archivo para importar tareas.");
                 }
        }
    
       
}

