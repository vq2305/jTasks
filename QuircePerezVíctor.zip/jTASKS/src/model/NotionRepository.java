package model;
import notion.api.v1.NotionClient;
import notion.api.v1.http.OkHttp5Client;
import notion.api.v1.logging.Slf4jLogger;
import notion.api.v1.model.databases.QueryResults;
import notion.api.v1.model.pages.Page;
import notion.api.v1.model.pages.PageParent;
import notion.api.v1.model.pages.PageProperty;
import notion.api.v1.model.pages.PageProperty.RichText;
import notion.api.v1.model.pages.PageProperty.RichText.Text;
import notion.api.v1.request.databases.QueryDatabaseRequest;
import notion.api.v1.request.pages.CreatePageRequest;
import notion.api.v1.request.pages.UpdatePageRequest;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import java.util.Map;


 
public class NotionRepository implements IRepository{

    private final NotionClient client;
    private final String databaseId;
    private final String titleColumnName = "Identificador"; // Este es el nombre de la columna que se utilizará 
                                                         // como clave primaria única de type Title en Notion

    public NotionRepository(String apiToken, String databaseId) {
        // Crear cliente de Notion
        this.client = new NotionClient(apiToken);

        // Configurar cliente HTTP adecuado y tiempos de espera
        client.setHttpClient(new OkHttp5Client(60000,60000,60000));

        // Configurar loggers
        client.setLogger(new Slf4jLogger());
        
        // Silenciar/Activar los registros de log de Notion API
        // Ver en nivel debug los mensajes de depuración
        System.setProperty("notion.api.v1.logging.StdoutLogger", "debug");

        

        this.databaseId = databaseId;
    }

    // Crear un registro en la base de datos
    @Override
public boolean addTask(Task task) throws RepositoryException {
    System.out.println("Creando una nueva página...");
    try {
        // Verificar si ya existe una tarea con el mismo identificador
        String existingPageId = findPageIdByIdentifier(Long.toString(task.getIdentifier()));
        if (existingPageId != null) {
            throw new RepositoryException("Ya existe una tarea con el identificador: " + task.getIdentifier());
        }

        // Crear las propiedades de la página
        Map<String, PageProperty> properties = Map.of(
            "Identificador", createTitleProperty(Long.toString(task.getIdentifier())),
            "Titulo", createRichTextProperty(task.getTitle()),
            "Contenido", createRichTextProperty(task.getContent()),
            "Fecha", createDateProperty(dateToString(task.getDate())),
            "Prioridad", createNumberProperty(task.getPriority()),
            "Duración Estimada", createNumberProperty(task.getEstimatedDuration()),
            "¿Completada?", createCheckboxProperty(task.isCompleted())
        );

        // Configurar la página padre de la database
        PageParent parent = PageParent.database(databaseId);

        // Crear la solicitud a la API de Notion
        CreatePageRequest request = new CreatePageRequest(parent, properties);

        // Ejecutar la solicitud (necesita de conexión a internet)
        Page response = client.createPage(request);

        // Este identificador es el interno de Notion no el campo Identifier de tipo Title
        System.out.println("Página creada con ID (interno Notion): " + response.getId());
        return true;
    } catch (Exception e) {
        throw new RepositoryException("Error al crear la tarea: " + e.getMessage(), e);
    }
}


    // Obtener todos los registros
    @Override
    public ArrayList<Task> getAllTasks() throws RepositoryException {
        ArrayList<Task> tasks = new ArrayList<>();
        try {
            // Crear la solicitud para consultar la base de datos
            QueryDatabaseRequest queryRequest = new QueryDatabaseRequest(databaseId);

            // Ejecutar la consulta
            QueryResults queryResults = client.queryDatabase(queryRequest);

            // Procesar los resultados
            for (Page page : queryResults.getResults()) {
                Map<String, PageProperty> properties = page.getProperties();
                Task task = mapPageToTask(page.getId(), properties);
                if (task != null) {
                    tasks.add(task);
                }
            }
        } catch (Exception e) {
            throw new RepositoryException("Error al obtener todas las tareas: " +e);
        }
        return tasks;
    }
    @Override
    public boolean isCompleted(long taskId) throws RepositoryException {
        Task task = getTaskById(taskId);
        if(task.isCompleted()){
            return true;
        }
        else{
            return false;
        }
    }
    @Override
    public boolean markTaskAsIncompleted(long taskId) throws RepositoryException {
        Task task = getTaskById(taskId);
        if (task == null) {
            throw new RepositoryException("No se puede eliminar una tarea inexistente con el ID: " + taskId);
        }
        task.setCompleted(false);
        deleteTask(taskId);
        addTask(task);
        return true;
    }

    @Override
    public boolean markTaskAsCompleted(long taskId) throws RepositoryException {
        Task task = getTaskById(taskId);
        if (task == null) {
            throw new RepositoryException("No se puede eliminar una tarea inexistente con el ID: " + taskId);
        }
        task.setCompleted(true);
        deleteTask(taskId);
        addTask(task);
        return true;
    }

    @Override
    public ArrayList<Task> getTasksByPriority() throws RepositoryException {
        ArrayList<Task> tasks = new ArrayList<>();
        try {
            // Crear la solicitud para consultar la base de datos
            QueryDatabaseRequest queryRequest = new QueryDatabaseRequest(databaseId);

            // Ejecutar la consulta
            QueryResults queryResults = client.queryDatabase(queryRequest);

            // Procesar los resultados
            for (Page page : queryResults.getResults()) {
                Map<String, PageProperty> properties = page.getProperties();
                Task task = mapPageToTask(page.getId(), properties);
                if (task != null) {
                    tasks.add(task);
                }
            }
        } catch (Exception e) {
            throw new RepositoryException("Error al obtener todas las tareas: " + e);
        }
        tasks.sort(Comparator.comparingInt(Task::getPriority).reversed());

        return tasks;
    }
    

    // Actualizar un registro por Identifier
    @Override
    public boolean updateTask(Task task) throws RepositoryException{
        try {
            
            
            String pageId = findPageIdByIdentifier(Long.toString(task.getIdentifier()));
            if (pageId == null) {
                System.out.println("No se encontró un registro con el Identificador: " + task.getIdentifier());
                return false;
            }

            // Crear las propiedades actualizadas
            Map<String, PageProperty> updatedProperties = Map.of(
                "Identificador", createTitleProperty(Long.toString(task.getIdentifier())),
                "Titulo", createRichTextProperty(task.getTitle()),
                "Contenido", createRichTextProperty(task.getContent()),
                "Fecha", createDateProperty(dateToString(task.getDate())),
                "Prioridad", createNumberProperty(task.getPriority()),
                "Duración Estimada", createNumberProperty(task.getEstimatedDuration()),       
                "¿Completada?", createCheckboxProperty(task.isCompleted())

            );

            // Crear la solicitud de actualización
            UpdatePageRequest updateRequest = new UpdatePageRequest(pageId, updatedProperties);
            client.updatePage(updateRequest);

            System.out.println("Página actualizada con ID (interno Notion)" + pageId);
            return true;
        } catch (Exception e) {
            throw new RepositoryException("Error al actualizar la pagina. "+e);
        }
    }

    // Eliminar (archivar) un registro por Identifier
    @Override
    public boolean deleteTask(long id) throws RepositoryException {
        try {
            Task t=getTaskById(id);
            
            String pageId = findPageIdByIdentifier(Long.toString(t.getIdentifier()));
            if (pageId == null) {
                System.out.println("No se encontró un registro con el Identifier: " + id);
                return false;
            }
            // Archivar la página
            UpdatePageRequest updateRequest = new UpdatePageRequest(pageId, Collections.emptyMap(), true);
            client.updatePage(updateRequest);
            System.out.println("Página archivada con ID (interno Notion)" + pageId);
            return true;
        } catch (Exception e) {
            throw new RepositoryException("Error al eliminar la pagina. "+e);
        }
    }

    private String findPageIdByIdentifier(String identifier) throws RepositoryException {
        try {
            QueryDatabaseRequest queryRequest = new QueryDatabaseRequest(databaseId);
            QueryResults queryResults = client.queryDatabase(queryRequest);

            for (Page page : queryResults.getResults()) {
                Map<String, PageProperty> properties = page.getProperties();
                if (properties.containsKey(titleColumnName) &&
                        properties.get(titleColumnName).getTitle().get(0).getText().getContent().equals(identifier)) {
                    return page.getId();
                }
            }
        } catch (Exception e) {
            throw new RepositoryException("Error al encontrar el identificador de pagina. "+e);
        }
        return null;
    }

    // Buscar el ID (interno de Notion) de una página por Identifier (atributo Title de la Database de Notion)
    @Override
    public Task getTaskById(long id) throws RepositoryException {
        try {
            QueryDatabaseRequest queryRequest = new QueryDatabaseRequest(databaseId);
            QueryResults queryResults = client.queryDatabase(queryRequest);
            String identifier=Long.toString(id);

            for (Page page : queryResults.getResults()) {
                Map<String, PageProperty> properties = page.getProperties();
                if (properties.containsKey(titleColumnName) &&
                        properties.get(titleColumnName).getTitle().get(0).getText().getContent().equals(identifier)) {
                    return mapPageToTask(page.getId(), properties);
                }
                
            }
            return null;
        } catch (Exception e) {
            throw new RepositoryException("Error al obtener la pagina. "+e);
        }
       
    }

    // Métodos auxiliares para crear propiedades de página
    private PageProperty createTitleProperty(String title) {
        RichText idText = new RichText();
        idText.setText(new Text(title));
        PageProperty idProperty = new PageProperty();
        idProperty.setTitle(Collections.singletonList(idText));
        return idProperty;
    }

    // Metodos auxiliares para crear propiedades de página
    private PageProperty createRichTextProperty(String text) {
        RichText richText = new RichText();
        richText.setText(new Text(text));
        PageProperty property = new PageProperty();
        property.setRichText(Collections.singletonList(richText));
        return property;
    }

    private PageProperty createNumberProperty(Integer number) {
        PageProperty property = new PageProperty();
        property.setNumber(number);
        return property;
    }

    private PageProperty createDateProperty(String date) {
        PageProperty property = new PageProperty();
        PageProperty.Date dateProperty = new PageProperty.Date();
        dateProperty.setStart(date);
        property.setDate(dateProperty);
        return property;
    }

    private PageProperty createCheckboxProperty(boolean checked) {
        PageProperty property = new PageProperty();
        property.setCheckbox(checked);
        return property;
    }

    // Mapeo de propiedades de Notion a un objeto Task
    private Task mapPageToTask(String pageId, Map<String, PageProperty> properties) throws RepositoryException {
        try {
            Task task = new Task();
            
            task.setIdentifier(Long.parseLong((properties.get("Identificador").getTitle().get(0).getText().getContent())));
            task.setTitle(properties.get("Titulo").getRichText().get(0).getText().getContent());
            task.setDate(stringToDate(properties.get("Fecha").getDate().getStart()));
            task.setContent(properties.get("Contenido").getRichText().get(0).getText().getContent());
            task.setPriority(properties.get("Prioridad").getNumber().intValue());
            task.setEstimatedDuration(properties.get("Duración Estimada").getNumber().intValue());
            task.setCompleted(properties.get("¿Completada?").getCheckbox());
            return task;
        } catch (Exception e) {
            throw new RepositoryException("Error al pasar la pagina a un objeto Task. "+e);
            
        }
    }

    public static String dateToString(Date date) {
        // Define el formato ISO 8601
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        return formatter.format(date); // Convierte el objeto Date a String en formato ISO 8601
    }
    

    public static Date stringToDate(String dateStr) throws RepositoryException {
        // Crear un formateador de fecha con el formato especificado
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        
        try {
            // Intentar analizar el string en un objeto Date
            return dateFormat.parse(dateStr);
        } catch (ParseException e) {
            // Imprimir el error si ocurre
            throw new RepositoryException("Error al convertir el string a fecha: " + e);
            
        }
    }

    @Override
    public boolean loadData(){
        return true;
        //A diferencia de en el BinaryRepository, este metodo no seria necesario, el programa trata con los datos en tiempo real.

    }

    @Override
    public boolean saveData(){
        return true;
        //A diferencia de en el BinaryRepository, este metodo no seria necesario, el programa va guardando los datos en tiempo real.
    }
}
