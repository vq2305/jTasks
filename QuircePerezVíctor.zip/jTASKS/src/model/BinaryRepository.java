package model;

import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;


public class BinaryRepository implements IRepository {

    private final String filePath; // Ruta al archivo binario
    private ArrayList<Task> tasks; // Colección en memoria de tareas

    public BinaryRepository() throws RepositoryException {
        this.filePath = System.getProperty("user.home") + File.separator + "tasks.bin";
        this.tasks = new ArrayList<Task>();
        
    }


    

    @SuppressWarnings("unchecked")
    @Override
    public boolean loadData() throws RepositoryException {
        File file = new File(filePath);
        if (file.exists()) {
            if (file.length() == 0) {
                // El archivo existe pero está vacío
                return false;
            }
    
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
                tasks = (ArrayList<Task>) ois.readObject();
                return true;
            } catch (IOException | ClassNotFoundException e) {
                throw new RepositoryException("Error al cargar los datos: " + e.getMessage());
            }
        } else {
            return false;
        }
    }
    

    @Override
    public boolean saveData() throws RepositoryException {
        File file = new File(filePath);
       
        if (!file.exists() || !file.canWrite()) {
            throw new RepositoryException("Archivo no existe o no tiene permisos de escritura: " + filePath);
        }
  
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filePath))) {
            out.writeObject(tasks);
            return true;
        }
         catch (IOException e) {
            throw new RepositoryException("Error al guardar los datos: " + e.getMessage(), e);
        }
    }
    

   

    


    

    @Override
    public ArrayList<Task> getAllTasks() throws RepositoryException {
        if (tasks == null) {
            throw new RepositoryException("No hay tareas cargadas en memoria.");
        }
        return (tasks);
    }

    @Override
    public boolean addTask(Task task) throws RepositoryException {
    
    if (task == null) {
            throw new RepositoryException("No se puede agregar una tarea nula.");
    }
    boolean taskExists = tasks.stream().anyMatch(existingTask -> existingTask.getIdentifier() == task.getIdentifier());
   
    if (taskExists) {
        throw new RepositoryException("La tarea ya existe con el ID: " + task.getIdentifier());
    }

        tasks.add(task);
        return true;
    }

    

    @Override
    public ArrayList<Task> getTasksByPriority() throws RepositoryException{
        if (tasks == null || tasks.isEmpty()) {
            throw new RepositoryException("No hay tareas disponibles para ordenar por prioridad.");
        }
        tasks.sort(Comparator.comparingInt(Task::getPriority).reversed());
        return (tasks);
    }

    @Override
    public Task getTaskById(long taskId) throws RepositoryException {
        return tasks.stream()
                .filter(task -> task.getIdentifier() == taskId)
                .findFirst()
                .orElseThrow(() -> new RepositoryException("Tarea no encontrada."));
    }

    @Override
    public boolean deleteTask(long taskId) throws RepositoryException {
        Task task = getTaskById(taskId);
        if (task == null) {
            throw new RepositoryException("No se puede eliminar una tarea inexistente con el ID: " + taskId);
        }
        tasks.remove(task);
        return true;
    }

    @Override
    public boolean isCompleted(long taskId) throws RepositoryException {
        Task task = getTaskById(taskId);
        return task.isCompleted();
        
    }

    @Override
    public boolean markTaskAsIncompleted(long taskId) throws RepositoryException {
        Task task = getTaskById(taskId);
        if (task == null) {
            throw new RepositoryException("No se puede marcar como incompleta una tarea inexistente con el ID: " + taskId);
        }
        task.setCompleted(false);
        return true;
    }

    @Override
    public boolean markTaskAsCompleted(long taskId) throws RepositoryException {
        Task task = getTaskById(taskId);
        if (task == null) {
            throw new RepositoryException("No se puede marcar como completa una tarea inexistente con el ID: " + taskId);
        }
        task.setCompleted(true);
        return true;
    }

    @Override
    public boolean updateTask(Task task) throws RepositoryException {
        if (task == null) {
            throw new RepositoryException("No se puede actualizar una tarea nula.");
        }
        Task existingTask = getTaskById(task.getIdentifier());
        tasks.remove(existingTask);
        tasks.add(task);
        return true;
        
    }

    
}
