package model;

public class ExporterFactory {
    public static IExporter getExporter(String type) throws RepositoryException {
        switch (type.toLowerCase()) {
            case "csv":
                return new CSVExporter();
            case "json":
                return new JSONExporter();
            default:
                throw new RepositoryException("Tipo de exporter no soportado: " + type);
        }
    }
}
