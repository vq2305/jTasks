package model;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class CSVExporter implements IExporter {
   
    
    @Override
    public boolean exportTasks(ArrayList<Task> tasks, Path path) throws RepositoryException {
               
        // Ordenar las tareas por fecha (más recientes primero)
        tasks.sort(Comparator.comparing(Task::getDate).reversed());
        File file = path.toFile();
        if (file.exists() && !file.canWrite()) {
            throw new RepositoryException("No se puede escribir en el archivo: " + file.getAbsolutePath());
        }

        ArrayList<String> lineas = new ArrayList<>();
        for (Task task : tasks) {
            lineas.add(task.getInstanceAsDelimitedString(","));
        }
        try {
            Files.write(path, lineas, StandardCharsets.UTF_8);
            return true;
        } catch (IOException e) {
                throw new RepositoryException("Error al exportar tareas al archivo delimitado"+ e);      
        }
    }

    @Override
    public List<Task> importTasks(Path path) throws RepositoryException {
        ArrayList<Task> tasks = new ArrayList<>();
        try {
            List<String> lineas = Files.readAllLines(path);
            for (String linea : lineas) {
                Task t = Task.getTaskFromDelimitedString(linea, ",");
                if(t != null){
                    tasks.add(t);
                }
            }
        
            // Ordenar las tareas por fecha (más recientes primero)
            tasks.sort(Comparator.comparing(Task::getDate).reversed());

        } catch (IOException e) {
            throw new RepositoryException("Error al importar tareas desde el archivo delimitado.  "+ e);
        }
         
        return tasks;
    }
}
