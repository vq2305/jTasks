package model;


import java.nio.file.Path;

import java.util.ArrayList;
import java.util.List;


public class Model {
    private IRepository repository;
    private IExporter exporter;


    public Model(IRepository repository ){
        this.repository=repository;
    }

    public void setExporter(IExporter exporter){
        this.exporter=exporter;
    }


    public boolean loadData() throws RepositoryException{
        return repository.loadData();
    }

    public boolean saveData() throws RepositoryException{
        return repository.saveData();
    }

    public boolean exportTasks(Path path) throws RepositoryException{
        if (exporter == null) {
            throw new IllegalStateException("No se ha configurado un exportador.");
        }
    
        try {
            ArrayList<Task> tasks = repository.getAllTasks();
    
            return exporter.exportTasks(tasks, path);
    
           
        } catch (Exception e) {
            
            throw new RepositoryException("Se ha producido un error durante la exportación."+ e);
        }
    }
    
    public boolean importTasks(Path path) throws RepositoryException{
       
    if (exporter == null) {
        throw new IllegalStateException("No se ha configurado un exportador.");
    }

    try {
        List<Task> importedTasks = exporter.importTasks(path);

        for (Task task : importedTasks) {
            repository.addTask(task);
        }
        return true;
    } catch (Exception e) {
        
        throw new RepositoryException("Se ha producido un error durante la exportación."+ e);
    }
        
    
}

    public IExporter getExporter(String type) throws RepositoryException{
        return ExporterFactory.getExporter(type);
    }
    
    public boolean addTask(Task task) throws RepositoryException{
        return repository.addTask(task);
    }

    public ArrayList<Task> getTasksByPriority() throws RepositoryException{
        return repository.getTasksByPriority();
    }

    public ArrayList<Task> getAllTasks() throws RepositoryException{
        return repository.getAllTasks();
    }

    public Task getTaskById(long taskId) throws RepositoryException{
        return repository.getTaskById(taskId);
    }

    public boolean deleteTask(long taskId) throws RepositoryException{
        return repository.deleteTask(taskId);
    }

    public boolean isCompleted(long taskId) throws RepositoryException{
        return repository.isCompleted(taskId);
    }
    public boolean markTaskAsIncompleted(long taskId) throws RepositoryException{
        return repository.markTaskAsIncompleted(taskId);
    }

    public boolean markTaskAsCompleted(long taskId) throws RepositoryException{
        return repository.markTaskAsCompleted(taskId);
    }

    public boolean updateTask(Task task) throws RepositoryException{
        return repository.updateTask(task);
    }
}
