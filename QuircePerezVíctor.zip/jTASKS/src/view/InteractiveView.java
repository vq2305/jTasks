package view;
import static com.coti.tools.Esdia.*;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.UUID;
import java.util.ArrayList;


import model.RepositoryException;
import model.Task;



public class InteractiveView extends BaseView {
    Scanner scanner = new Scanner(System.in);
    

    @Override
    public void init() throws RepositoryException {
        showMessage("Bienvenido al gestor de tareas jTASKS");
        boolean running=true;

        while(running){
            showMenu();
            int option=readInt("Introduzca la opcion que desea: ");
            switch (option){
                case 1: 
                    interactiveMenu();
                    break;
                case 2:
                    exportImportMenu();
                    break;
                case 3: 
                    controller.end();
                    running=false;
                    scanner.close();
                    break;
                default: 
                    showErrorMessage("Opción no valida. Vuelva a ingresar otra opcion. ");
            }
        }
    
    }
    @Override
    public void showMessage(String message){
        System.out.println(""+message);
    }

    @Override
    public void showErrorMessage(String errorMessage){
        System.out.println(""+errorMessage);
    }

    @Override
    public void end(){
        showMessage("Gracias por usar este gestor de tareas. Saliendo...");

    }

    private void showMenu(){
        showMessage("\nMenú Principal:");
        showMessage("1. Gestión de tareas (CRUD)");
        showMessage("2. Exportación/Importación");
        showMessage("3. Salir y Guardar");
        
    }
    private void interactiveMenu() throws RepositoryException{
        boolean running=true;
        while(running){
            showIMenu();
            int option=readInt("Introduzca la opcion que desee: ");
            switch(option){
                case 1:
                createTask();
                break;
            case 2:
                listTasksByPriority();
                break;
            case 3:
                listAllTasks();
                break;
            case 4:
                viewTaskDetails();
                break;
            case 5:
                running = false;
                break;
            default:
                showErrorMessage("Opción no válida. Escoga otra opcion valida. ");
            }
        }
    }
    private void showIMenu(){
        showMessage("\nMenú de Tareas:");
            showMessage("1. Crear nueva tarea");
            showMessage("2. Listar tareas por prioridad");
            showMessage("3. Listar todas las tareas");
            showMessage("4. Ver detalle de una tarea");
            showMessage("5. Volver al menú principal");
    }

    private void exportImportMenu() throws RepositoryException{
        showEIMenu();
        int option = readInt("Introduzca la opcion que desee: ");
        try {
            switch (option) {
                case 1:
                    exportTasks();
                    break;
                case 2:
                    importTasks();
                    break;
                case 3:
                    return;
                default:
                    showErrorMessage("Opción no válida. Intente nuevamente.");
            }
        } catch (Exception e) {
            showErrorMessage("Error: " + e.getMessage());
        }
    }

    private void showEIMenu(){
        showMessage("Menu de importacion/exportacion.");
        showMessage("1. Exportar tareas");
        showMessage("2. Importar tareas.");
        showMessage("3. Salir.");
        
    }
    
    private void createTask() throws RepositoryException {
        showMessage("Crea nueva tarea:\n");
        long identifier=Math.abs(UUID.randomUUID().getLeastSignificantBits());
        String title=readString("Introduzca el titulo de la tarea: ");
        Date date=readDate("Introduzca la fecha de la tarea (dd/MM/yyyy): ");
        String content=readString("Introduzca el contenido de la tarea: ");
        int priority=readInt("Introduzca la prioridad de la tarea, 1(Baja)-5(Alta): ");
        int estimatedDuration=readInt("Introduzca la duracion estimada en minutos: ");
        boolean completed=readBoolean("Tarea completa o incompleta (C/I): ");
        if(controller.addTask(new Task(identifier, title, date, content, priority, estimatedDuration, completed))){
        showMessage("Tarea agreagada correctamente.");}
        else{
            showMessage("Tarea no agregada.");
        }
   
    }

    private Date readDate(String message) {
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    sdf.setLenient(false); // Validar fechas estrictamente (evitar cosas como 31/02/2024).
    Date date = null;

    while (date == null) {
        try {
            String input = readString(message);
            date = sdf.parse(input); // Convertir el texto ingresado en una fecha.
        } catch (ParseException e) {
            showErrorMessage("Formato de fecha inválido. Por favor, usa el formato dd/MM/yyyy.");
        }
    }

    return date;
}


private boolean readBoolean(String message) {
    boolean running = false;
    boolean result = false;

    while (!running) {
        String option = readString(message);
        switch (option.toUpperCase()) {
            case "C":
                result = true;
                running = true;
                break;
            case "I":
                result = false;
                running = true; 
                break;
            default:
                showErrorMessage("La opción introducida es incorrecta. Vuelva a introducir otra opción.");
                break;
        }
    }
    return result; 
}

private void listTasksByPriority() throws RepositoryException{
        ArrayList<Task>tareasDisponibles=controller.getTasksByPriority();

        if (!tareasDisponibles.isEmpty()) {
            String cabecera1 = String.format("|%-130s|", "Tareas disponibles");
            showMessage("-".repeat(cabecera1.length()));
            showMessage(cabecera1);
            showMessage("-".repeat(cabecera1.length()));
            String cabecera2 = String.format("|%-20s|%-10s|%-30s|%-30s|%-10s|%-10s|%-12s|", "Identificador", "Titulo", "Fecha", "Contenido", "Prioridad", "Duracion", "¿Completada?");
            showMessage(cabecera2);
            showMessage("-".repeat(cabecera2.length()));

            
            for (Task task : tareasDisponibles) {
                String mensaje=(String.format("|%20d|%10s|%30s|%30s|%10d|%10d|%12s|",task.getIdentifier(),task.getTitle(),task.getDate().toString(), 
                task.getContent(), task.getPriority(), task.getEstimatedDuration(), task.isCompleted() ? "Sí" : "No"));
                showMessage(mensaje);
            }
            showMessage("-".repeat(cabecera2.length()));

        } else {
            showMessage("|NO HAY TAREAS DISPONIBLES|");
        }
    }
    private void listAllTasks() throws RepositoryException{
        ArrayList<Task>tareasDisponibles=controller.getAllTasks();

        if (!tareasDisponibles.isEmpty()) {
            String cabecera1 = String.format("|%-130s|", "Tareas disponibles");
            showMessage("-".repeat(cabecera1.length()));
            showMessage(cabecera1);
            showMessage("-".repeat(cabecera1.length()));
            String cabecera2 = String.format("|%-20s|%-10s|%-30s|%-30s|%-10s|%-10s|%-12s|", "Identificador", "Titulo", "Fecha", "Contenido", "Prioridad", "Duracion", "¿Completada?");
            showMessage(cabecera2);
            showMessage("-".repeat(cabecera2.length()));


            for (Task task : tareasDisponibles) {
                String mensaje=(String.format("|%10d|%10s|%30s|%30s|%10d|%10d|%12s|",task.getIdentifier(),task.getTitle(),task.getDate().toString(), 
                task.getContent(), task.getPriority(), task.getEstimatedDuration(), task.isCompleted() ? "Sí" : "No"));
                showMessage(mensaje);

            }
            showMessage("-".repeat(cabecera2.length()));

        } else {
            showMessage("|NO HAY TAREAS DISPONIBLES|");
        }
    }


    private void viewTaskDetails() throws RepositoryException{
        long taskId=readLong("Introduzca el ID de la tarea a revisar: ");
        Task task=controller.getTaskById(taskId);
        if(task!=null){
            
            showMessage("1. Marcar como completa/incompleta");
            showMessage("2. Modificar información");
            showMessage("3. Eliminar tarea");
            showMessage("4. Volver");
            int option=readInt("Seleccione una opción: ");

            switch (option){
                case 1: 
                    completedTask(taskId);
                    break;
                case 2: 
                    updateTask(taskId);
                    break;
                case 3: 
                    if(controller.deleteTask(taskId)){
                    showMessage(" Tarea eliminada correctamente.");}
                    break;
                case 4: 
                    return;
                default: 
                    showErrorMessage("Introduzca la opcion correcta.");

            }
        }
        else{
            showErrorMessage("Error al encontrar la tarea.");
        }
    }


    private void completedTask(long taskId) throws RepositoryException{
        if(controller.isCompleted(taskId)){
            showMessage("La tarea introducida está completa.");
            String option= readString("¿Desea marcarla como incompleta? (S/N): ");
            boolean running=true;
            while(running){
            switch(option.toUpperCase()){
                case "S":
                    if(controller.markTaskAsIncompleted(taskId)){
                        showMessage("Tarea marcada como incompleta.");}
                    running=false;
                    break;
                case "N":
                    showMessage("La tarea continuara como completa.");
                    running=false;
                    break;
                default:
                    showMessage("Introduzca una opcion correcta:");
                    break;
            }

        }
    

        }
        else{
            showMessage("La tarea introducida está incompleta.");
            String option= readString("¿Desea marcarla como completa? (S/N): ");
            boolean running2=true;
            while(running2){
            switch(option.toUpperCase()){
                case "S":
                    if(controller.markTaskAsCompleted(taskId)){
                    showMessage("Tarea marcada como completa.");
                    running2=false;}
                    break;
                case "N":
                    showMessage("La tarea continuara como incompleta.");
                    running2=false;
                    break;
                default:
                    showMessage("Introduzca una opcion correcta:");
                    break;
            }

        }
        }
    }

    private void updateTask(long taskId) throws RepositoryException{
        String title=readString("Introduzca el titulo de la tarea: ");
        Date date=readDate("Introduzca la fecha de la tarea (dd/MM/yyyy): ");
        String content=readString("Introduzca el contenido de la tarea: ");
        int priority=readInt("Introduzca la prioridad de la tarea, 1(Baja)-5(Alta): ");
        int estimatedDuration=readInt("Introduzca la duracion estimada en minutos: ");
        boolean completed=readBoolean("Tarea completa o incompleta (C/I): ");
        if(controller.updateTask(new Task(taskId, title, date, content, priority, estimatedDuration, completed))){
        showMessage("Tarea actualizada exitosamente.");}
        }


    private void exportTasks() throws RepositoryException{
        String option=readString("Introduzca el formato de exportacion (CSV/JSON): ");
        switch(option.toLowerCase()){
            case "csv": 
                 
                    String ubicacion=readString("Introduzca la ruta: ");
                    if (!ubicacion.endsWith(".csv")) {
                        System.out.println("Error: La ruta debe terminar con '.csv'.");
                        return;                     
                    }
                    Path path=Paths.get(ubicacion);                  
                    controller.exportTasks(option, path);
                    break;
            case "json": 
                    String ruta=readString("Introduzca la ruta: ");
                    if (!ruta.endsWith(".json")) {
                        System.out.println("Error: La ruta debe terminar con '.json'.");
                        return; // Salir si la ruta no es válida
                    }
                    
                    Path path2=Paths.get(ruta);
                    
                    controller.exportTasks(option, path2);
                    break;


        }
        
    }
    private void importTasks() throws RepositoryException{
        
        String option=readString("Introduzca el formato de importacion (CSV/JSON): ");
        switch(option.toLowerCase()){
            case "csv": 
                   
                    String ubicacion=readString("Introduzca la ruta: ");
                    if (!ubicacion.endsWith(".csv")) {
                        System.out.println("Error: La ruta debe terminar con '.csv'.");
                        return;                     
                    }

                    Path path=Paths.get(ubicacion);
                    controller.importTasks(option, path);
                    break;
            case "json": 
                    String ruta=readString("Introduzca la ruta: ");
                    if (!ruta.endsWith(".json")) {
                        System.out.println("Error: La ruta debe terminar con '.json'.");
                        return; 
                    }

                    Path path2=Paths.get(ruta);
                    controller.importTasks(option, path2);
                    break;


        }
        
    }

    

public long readLong(String message) {
    
    long number = 0;
    boolean running = false;

    while (!running) {
        try {
            System.out.print(message);
            number = Long.parseLong(scanner.nextLine()); 
            running  = true; 
        } catch (NumberFormatException e) {
            System.out.println("Entrada inválida. Por favor, ingrese un número válido.");
        }
    }

    return number;
}

}
