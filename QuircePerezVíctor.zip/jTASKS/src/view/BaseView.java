package view;


import controller.Controller;

import model.RepositoryException;

public abstract class BaseView{
   protected Controller controller;


   public void setController(Controller controller){
    this.controller=controller;
   }
   public abstract void init() throws RepositoryException;
   public abstract void showMessage(String message);
   public abstract void showErrorMessage(String errorMessage);
   public abstract void end();

   

}
    
