

import controller.Controller;
import model.BinaryRepository;

import model.IRepository;
import model.Model;

import view.BaseView;
import view.InteractiveView;
import model.NotionRepository;



public class App {

    public static void main(String[] args) throws Exception {
        
        // String API_KEY = "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";
        // String DATABASE_ID = "158a65a8b7c180e28560e4999c8e3455";
        IRepository repository;

        // Verificar los argumentos pasados por línea de comandos
        if (args.length > 0 && args[0].equalsIgnoreCase("--repository")) {

            if (args.length > 1 && args[1].equalsIgnoreCase("notion")) {

                if (args.length == 4) {
                    String API_KEY = args[2];
                    String DATABASE_ID = args[3];
                    repository = new NotionRepository(API_KEY, DATABASE_ID);

                } else {
                    System.err.println("Error: Para usar Notion, debe proporcionar API_KEY y DATABASE_ID.");
                    return;
                }
            } else {
                repository = new BinaryRepository(); // Repositorio binario por defecto
            }
        } else {
            repository = new BinaryRepository(); // Repositorio binario por defecto
        }
      

         System.out.println("Repositorio inicializado: " + repository.getClass().getSimpleName());

        Model model = new Model(repository);
        BaseView view=new InteractiveView();

        Controller controller = new Controller(model, view);   

        controller.start();
       
    }

    }

