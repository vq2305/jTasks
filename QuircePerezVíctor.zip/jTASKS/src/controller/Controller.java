package controller;


import model.IExporter;
import model.Model;
import model.RepositoryException;
import view.BaseView;
import model.Task;

import java.nio.file.Path;
import java.text.ParseException;
import java.util.ArrayList;


public class Controller {
    private Model model;
    private BaseView view;


    public Controller(Model model, BaseView view){
        this.model=model;
        this.view=view;
        this.view.setController(this);
    }

    public void start() throws RepositoryException, ParseException {

        try {
            model.loadData(); 
            view.showMessage("Datos cargados correctamente.");
        } catch (Exception e) {
            view.showErrorMessage("Error al cargar los datos: " + e.getMessage());
        }
        view.init(); 
    }


    public void end() {
        try {
            model.saveData();
            view.showMessage("Datos guardados correctamente. La aplicación se cerrará.");
            view.end();
        } catch (Exception e) {
            view.showErrorMessage("Error al guardar los datos: " + e.getMessage());
        }
        
    }

    public boolean addTask(Task task) throws RepositoryException{
        return model.addTask(task);
    }

    public ArrayList<Task> getTasksByPriority() throws RepositoryException{
        return model.getTasksByPriority();
    }

    public ArrayList<Task> getAllTasks() throws RepositoryException{
        return model.getAllTasks();
    }

    public Task getTaskById(long taskId) throws RepositoryException{
        return model.getTaskById(taskId);
    }

    public boolean deleteTask(long taskId) throws RepositoryException {
        return model.deleteTask(taskId);
    }

    public boolean isCompleted(long taskId) throws RepositoryException{
        return model.isCompleted(taskId);
    }

    public boolean markTaskAsIncompleted(long taskId) throws RepositoryException{
        return model.markTaskAsIncompleted(taskId);
    }

    public boolean markTaskAsCompleted(long taskId) throws RepositoryException{
        return model.markTaskAsCompleted(taskId);
    }

    public boolean updateTask(Task task) throws RepositoryException{
        return model.updateTask(task);
    }

    public boolean importTasks(String type, Path path ) throws RepositoryException{

    IExporter exporter = model.getExporter(type);
    model.setExporter(exporter);
    return model.importTasks(path);

    }
    public boolean exportTasks(String type, Path path) throws RepositoryException{

        IExporter exporter = model.getExporter(type);
        model.setExporter(exporter);
        return model.exportTasks(path);
    
        }

}
